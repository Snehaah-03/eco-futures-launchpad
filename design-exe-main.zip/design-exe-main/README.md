![Untitled-3](design.png)
# **[Project Name]**


**DESIGN.EXE designathon 2025**

> A short description of your project. Explain what your project does, what problem it solves, and why it's cool.


## **Link to figma file**
Add the link here

## **Hosted url**
Add the link here

## **Installation**
How on earth can we set up your project up and running?

## **Steps to run**  
Care to explain?

## **Acknowledgements**
Give credit to any resources, tutorials, libraries helped you build your project.

